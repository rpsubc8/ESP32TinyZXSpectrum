//#include "def/files.h"
//#include "def/msg.h"
//JJ#include "Wiimote2Keys.h"

// Cursor to OSD first row,col
//void osdHome() { vga.setCursor(osdInsideX(), osdInsideY()); }

// Cursor positioning
//void osdAt(byte row, byte col) {
//    if (row > osdMaxRows() - 1)
//        row = 0;
//    if (col > osdMaxCols() - 1)
//        col = 0;
//    unsigned short y = (row * OSD_FONT_H) + osdInsideY();
//    unsigned short x = (col * OSD_FONT_W) + osdInsideX();
//    vga.setCursor(x, y);
//}

//void drawOSD() {
//    unsigned short x = scrAlignCenterX(OSD_W);
//    unsigned short y = scrAlignCenterY(OSD_H);
//    //JJvga.fillRect(x, y, OSD_W, OSD_H, zxcolor(1, 0));
//    vga.fillRect(x, y, OSD_W, OSD_H, gb_cache_zxcolor[1]);
//    //JJvga.rect(x, y, OSD_W, OSD_H, zxcolor(0, 0));
//    vga.rect(x, y, OSD_W, OSD_H, gb_cache_zxcolor[0]);
//    //JJvga.rect(x + 1, y + 1, OSD_W - 2, OSD_H - 2, zxcolor(7, 0));
//    vga.rect(x + 1, y + 1, OSD_W - 2, OSD_H - 2, gb_cache_zxcolor[7]);
//    //JJvga.setTextColor(zxcolor(0, 0), zxcolor(5, 1));
//    vga.setTextColor(gb_cache_zxcolor[0], gb_cache_zxcolor[5]);//falta brillo
//    vga.setFont(Font6x8);
//    osdHome();
//    vga.print(OSD_TITLE);
//    osdAt(17, 0);
//    vga.print(OSD_BOTTOM);
//    osdHome();
//}


//No necesito grabar
//JJ static void quickSave()
//JJ{
//JJ    osdCenteredMsg(OSD_QSNA_SAVING, LEVEL_INFO);
//JJ    if (!save_ram_quick()) {
//JJ        osdCenteredMsg(OSD_QSNA_SAVE_ERR, LEVEL_WARN);
//JJ        delay(1000);
//JJ        return;
//JJ    }
//JJ    osdCenteredMsg(OSD_QSNA_SAVED, LEVEL_INFO);
//JJ    delay(200);
//JJ}

//JJstatic void quickLoad()
//JJ{
//JJ    if (!is_quick_sna_available()) {
//JJ        osdCenteredMsg(OSD_QSNA_NOT_AVAIL, LEVEL_INFO);
//JJ        delay(1000);
//JJ        return;
//JJ    }
//JJ    osdCenteredMsg(OSD_QSNA_LOADING, LEVEL_INFO);
//JJ    if (!load_ram_quick()) {
//JJ        osdCenteredMsg(OSD_QSNA_LOAD_ERR, LEVEL_WARN);
//JJ        delay(1000);
//JJ        return;
//JJ    }
//JJ    osdCenteredMsg(OSD_QSNA_LOADED, LEVEL_INFO);
//JJ    delay(200);
//JJ}

//JJstatic void persistSave()
//JJ{
//JJ    osdCenteredMsg(OSD_PSNA_SAVING, LEVEL_INFO);
//JJ    if (!save_ram(DISK_PSNA_FILE)) {
//JJ        osdCenteredMsg(OSD_PSNA_SAVE_ERR, LEVEL_WARN);
//JJ        delay(1000);
//JJ        return;
//JJ    }
//JJ    osdCenteredMsg(OSD_PSNA_SAVED, LEVEL_INFO);
//JJ    delay(400);
//JJ}


//JJstatic void persistLoad()
//JJ{
//JJ    if (!is_persist_sna_available()) {
//JJ        osdCenteredMsg(OSD_PSNA_NOT_AVAIL, LEVEL_INFO);
//JJ        delay(1000);
//JJ        return;
//JJ    }
//JJ    osdCenteredMsg(OSD_PSNA_LOADING, LEVEL_INFO);
//JJ    load_ram(DISK_PSNA_FILE);
//JJ    // if (!load_ram(DISK_PSNA_FILE)) {
//JJ    //     osdCenteredMsg(OSD_PSNA_LOAD_ERR, LEVEL_WARN);
//JJ    //     delay(1000);
//JJ    // }
//JJ    osdCenteredMsg(OSD_PSNA_LOADED, LEVEL_INFO);
//JJ    delay(400);
//JJ}


// OSD Main Loop
/*void do_OSD() {
    //JJ static byte last_sna_row = 0;
    //JJ static unsigned int last_demo_ts = millis() / 1000;
    //JJ boolean cycle_sna = false;
     if (checkAndCleanKey(KEY_F12)) {
         //JJ cycle_sna = true;
     }
    //JJ else if (checkAndCleanKey(KEY_PAUSE)) {//quitamos pausa teclado
    //JJ     osdCenteredMsg(OSD_PAUSE, LEVEL_INFO);
    //JJ     while (!checkAndCleanKey(KEY_PAUSE)) {
    //JJ         delay(5);
    //JJ     }
    //JJ }
    //JJ else if (checkAndCleanKey(KEY_F2)) {//quitamos grabacion
    //JJ    quickSave();
    //JJ}
    //JJelse if (checkAndCleanKey(KEY_F3)) {//quitamos lectura
    //JJ    quickLoad();
    //JJ}
    //JJelse if (checkAndCleanKey(KEY_F4)) {//quitamos persistencia
    //JJ    persistSave();
    //JJ}
    //JJelse if (checkAndCleanKey(KEY_F5)) {//quitamos persistencia
    //JJ    persistLoad();
    //JJ}
    else if (checkAndCleanKey(KEY_F1)) {
        // Main menu
        byte opt = menuRun(MENU_MAIN);
        if (opt == 1) {
            // Change RAM
            //JJ revisar unsigned short snanum = menuRun(cfg_sna_name_list);
            cfg_sna_name_list =  (String)MENU_SNA_TITLE + "\n";
            for (unsigned char i=0;i<max_list_sna_48;i++)
             cfg_sna_name_list += (String)gb_list_sna_48k_title[i]+(String)"\n";
            unsigned short snanum = menuRun(cfg_sna_name_list); 
            if (snanum > 0) {
                //JJ if (cfg_demo_mode_on) {
                //JJ     setDemoMode(OFF, 0);
                //JJ }
                //JJ changeSna(rowGet(cfg_sna_file_list, snanum));
                changeSna2Flash((snanum-1));
            }
        }
        else if (opt == 2) {
            // Change ROM
            //JJ String arch_menu = getArchMenu();
            String arch_menu = (String)MENU_ARCH + (String)"48K\n128K\n";
            byte arch_num = menuRun(arch_menu);
            if (arch_num > 0) {
                //JJ String romset_menu = getRomsetMenu(rowGet(arch_menu, arch_num));
                String romset_menu = (String)MENU_ROMSET;
                cfg_arch = rowGet(arch_menu, arch_num);
                if (cfg_arch == "48K")
                {
                 for (unsigned char i=0;i<max_list_rom_48;i++)
                  romset_menu += (String)gb_list_roms_48k_title[i]+(String)"\n";
                }
                else
                {
                 for (unsigned char i=0;i<max_list_rom_128;i++)
                  romset_menu += (String)gb_list_roms_128k_title[i]+(String)"\n";
                }
                byte romset_num = menuRun(romset_menu);
                if (romset_num > 0) {
                    cfg_arch = rowGet(arch_menu, arch_num);
                    //JJ cfg_rom_set = rowGet(romset_menu, romset_num);
                    //JJ rom load_rom(cfg_arch, cfg_rom_set);
                    //Serial.printf("JJ num %d\n",romset_num);
                    //Serial.println(arch_menu);
                    //Serial.println(romset_menu);                    
                    load_rom2flash(((cfg_arch == "48K")?1:0),romset_num-1);                    
                    vTaskDelay(2);

                    //JJ save config_save();
                    vTaskDelay(2);
                    zx_reset();
                }
            }
        }
        else if (opt == 3) {
        //JJ    quickSave(); //lo quito
        }
        else if (opt == 4) {
        //JJ    quickLoad();
        }
        else if (opt == 5) {
        //JJ    persistSave();
        }
        else if (opt == 6) {
        //JJ    persistLoad();
        }
        else if (opt == 7) {
            // Reset
            byte opt2 = menuRun(MENU_RESET);
            if (opt2 == 1) {
                // Soft
                zx_reset();
            //JJ no sna   if (cfg_ram_file != (String)NO_RAM_FILE)
            //JJ        load_ram("/sna/" + cfg_ram_file);
            }
            else if (opt2 == 2) {
                // Hard
                //JJ cfg_ram_file = (String)NO_RAM_FILE;
                //JJ save config_save();
                zx_reset();
                ESP.restart();
            }
            else if (opt2 == 3) {
                // ESP host reset
                ESP.restart();
            }
        }
        else if (opt == 8) {
            // Help
            drawOSD();
            osdAt(2, 0);
            //JJvga.setTextColor(zxcolor(7, 0), zxcolor(1, 0));
            vga.setTextColor(gb_cache_zxcolor[7], gb_cache_zxcolor[1]);
            vga.print(OSD_HELP);
            while (!checkAndCleanKey(KEY_F1) && !checkAndCleanKey(KEY_ESC) && !checkAndCleanKey(KEY_ENTER)) {
                vTaskDelay(5);
                //JJupdateWiimote2KeysOSD();
            }
        }
        // Exit
    }

    //JJ if (cycle_sna || (cfg_demo_mode_on && ((millis() / 1000) - last_demo_ts) > cfg_demo_every)) {
        // Cycle over snapshots
        //JJ last_sna_row++;
        //JJ if (last_sna_row > rowCount(cfg_sna_file_list) - 1) {
        //JJ     last_sna_row = 1;
        //JJ }
        //JJ quito sna changeSna(rowGet(cfg_sna_file_list, last_sna_row));
        //JJ last_demo_ts = millis() / 1000;
        //JJ cycle_sna = false;
    //JJ }
}
*/