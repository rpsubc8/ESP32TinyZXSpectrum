/*
#include "gbOptimice.h"
#include "Disk.h"
#include "ZX-ESPectrum.h"
#include "def/Font.h"
#include "def/files.h"
#include "def/msg.h"
#include "osd.h"

extern unsigned char gb_cache_zxcolor[8];

// Shows a red panel with error text
void errorPanel(String errormsg) {
    unsigned short x = scrAlignCenterX(OSD_W);
    unsigned short y = scrAlignCenterY(OSD_H);

    if (cfg_slog_on)
        Serial.println(errormsg);

    stepULA();

    //JJvga.fillRect(x, y, OSD_W, OSD_H, zxcolor(0, 0));
    //JJvga.rect(x, y, OSD_W, OSD_H, zxcolor(7, 0));
    //JJvga.rect(x + 1, y + 1, OSD_W - 2, OSD_H - 2, zxcolor(2, 1));
    vga.fillRect(x, y, OSD_W, OSD_H, gb_cache_zxcolor[0]);
    vga.rect(x, y, OSD_W, OSD_H, gb_cache_zxcolor[7]);
    vga.rect(x + 1, y + 1, OSD_W - 2, OSD_H - 2, gb_cache_zxcolor[2]); //falta brillo
    vga.setFont(Font6x8);
    osdHome();
    //vga.setTextColor(zxcolor(7, 1), zxcolor(2, 1));
    vga.setTextColor(gb_cache_zxcolor[7], gb_cache_zxcolor[2]);//falta brillo
    vga.print(ERROR_TITLE);
    osdAt(2, 0);
    //JJvga.setTextColor(zxcolor(7, 1), zxcolor(0, 0));
    vga.setTextColor(gb_cache_zxcolor[7], gb_cache_zxcolor[0]); //falta brillo
    vga.println(errormsg.c_str());
    osdAt(17, 0);
    //JJvga.setTextColor(zxcolor(7, 1), zxcolor(2, 1));
    vga.setTextColor(gb_cache_zxcolor[7], gb_cache_zxcolor[2]);//falta brillo
    vga.print(ERROR_BOTTOM);
}

// Error panel and infinite loop
void errorHalt(String errormsg) {
    errorPanel(errormsg);
    while (1) {
        do_keyboard();
        do_OSD();
        delay(5);
    }
}

// Centered message
void osdCenteredMsg(String msg, byte warn_level) {
    const unsigned short w = (msg.length() + 2) * OSD_FONT_W;
    const unsigned short h = OSD_FONT_H * 3;
    const unsigned short x = scrAlignCenterX(w);
    const unsigned short y = scrAlignCenterY(h);
    unsigned short paper;
    unsigned short ink;

    switch (warn_level) {
    case LEVEL_OK:
        //JJ ink = zxcolor(7, 1);
        //JJ paper = zxcolor(4, 0);
        ink = (unsigned short)(gb_cache_zxcolor[7]); //falta brillo
        paper = (unsigned short)(gb_cache_zxcolor[4]);
        break;
    case LEVEL_ERROR:
        //JJ ink = zxcolor(7, 1);
        //JJ paper = zxcolor(2, 0);
        ink = (unsigned short)(gb_cache_zxcolor[7]); //falta brillo
        paper = (unsigned short)(gb_cache_zxcolor[2]); //falta brillo 
        break;
    case LEVEL_WARN:
        //JJink = zxcolor(0, 0);
        //JJpaper = zxcolor(6, 0);
        ink = (unsigned short)(gb_cache_zxcolor[0]);
        paper = (unsigned short)(gb_cache_zxcolor[6]);        
        break;
    default:
        //JJink = zxcolor(7, 0);
        //JJpaper = zxcolor(1, 0);
        ink = (unsigned short)(gb_cache_zxcolor[7]);
        paper = (unsigned short)(gb_cache_zxcolor[1]); 
        break;
    }

    stepULA();

    vga.fillRect(x, y, w, h, paper);
    // vga.rect(x - 1, y - 1, w + 2, h + 2, ink);
    vga.setTextColor(ink, paper);
    vga.setFont(Font6x8);
    vga.setCursor(x + OSD_FONT_W, y + OSD_FONT_H);
    vga.print(msg.c_str());
}
*/