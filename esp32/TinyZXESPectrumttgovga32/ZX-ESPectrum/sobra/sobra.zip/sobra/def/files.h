/*JJ
#define DISK_BOOT_FILENAME "/boot.cfg"
#define DISK_ROM_DIR "/rom"
#define DISK_SNA_DIR "/sna"
#define DISK_PSNA_FILE "/persist/persist.sna"
#define NO_RAM_FILE "none"
#define SIZE48K 49179
*/