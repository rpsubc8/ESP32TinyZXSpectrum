//JJ #include "def/files.h"
//#include "def/msg.h"
//JJ #include <FS.h>
//JJ #include <SPIFFS.h>

//JJ// Change running snapshot
//JJvoid changeSna(String sna_filename) {
//JJ    osdCenteredMsg((String)MSG_LOADING + ": " + sna_filename, LEVEL_INFO);
//JJ    zx_reset();
//JJ    Serial.printf("Loading sna: %s\n", sna_filename.c_str());
//JJ    load_ram((String)DISK_SNA_DIR + "/" + sna_filename);
//JJ    osdCenteredMsg(MSG_SAVE_CONFIG, LEVEL_WARN);
//JJ    cfg_ram_file = sna_filename;
//JJ    //JJ save config_save();
//JJ}

// Demo mode on off
//JJ void setDemoMode(boolean on, unsigned short every) {
//JJ     cfg_demo_mode_on = on;
//JJ     cfg_demo_every = (every > 0 ? every : 60);
//JJ     if (on) {
//JJ         osdCenteredMsg(OSD_DEMO_MODE_ON, LEVEL_OK);
//JJ     } else {
//JJ         osdCenteredMsg(OSD_DEMO_MODE_OFF, LEVEL_WARN);
//JJ     }
//JJ     Serial.printf("DEMO MODE %s every %u seconds.", (cfg_demo_mode_on ? "ON" : "OFF"), cfg_demo_every);
//JJ     vTaskDelay(200);
//JJ     //JJ osdCenteredMsg(MSG_SAVE_CONFIG, LEVEL_WARN);
//JJ     //JJ save config_save();
//JJ }

//JJ bool is_persist_sna_available()
//JJ {
//JJ     String filename = DISK_PSNA_FILE;
//JJ     return SPIFFS.exists(filename.c_str());
//JJ }


//JJ bool save_ram(String sna_file) {
//JJ     KB_INT_STOP;
//JJ 
//JJ     // only 48K snapshot supported at the moment
//JJ     if (cfg_arch != "48K") {
//JJ         Serial.println("save_ram: only 48K supported at the moment");
//JJ         KB_INT_START;
//JJ         return false;
//JJ     }
//JJ 
//JJ     // open file
//JJ     File f = SPIFFS.open(sna_file, FILE_WRITE);
//JJ     if (!f) {
//JJ         Serial.printf("save_ram: failed to open %s for writing\n", sna_file.c_str());
//JJ         KB_INT_START;
//JJ         return false;
//JJ     }
//JJ 
//JJ     // write registers: begin with I
//JJ     f.write(_zxCpu.i);
//JJ 
//JJ     // store registers
//JJ     unsigned short HL = _zxCpu.registers.word[Z80_HL];
//JJ     unsigned short DE = _zxCpu.registers.word[Z80_DE];
//JJ     unsigned short BC = _zxCpu.registers.word[Z80_BC];
//JJ     unsigned short AF = _zxCpu.registers.word[Z80_AF];
//JJ 
//JJ     // put alternates in registers
//JJ     _zxCpu.registers.word[Z80_HL] = _zxCpu.alternates[Z80_HL];
//JJ     _zxCpu.registers.word[Z80_DE] = _zxCpu.alternates[Z80_DE];
//JJ     _zxCpu.registers.word[Z80_BC] = _zxCpu.alternates[Z80_BC];
//JJ     _zxCpu.registers.word[Z80_AF] = _zxCpu.alternates[Z80_AF];
//JJ 
//JJ     // write alternates
//JJ     f.write(_zxCpu.registers.byte[Z80_L]);
//JJ     f.write(_zxCpu.registers.byte[Z80_H]);
//JJ     f.write(_zxCpu.registers.byte[Z80_E]);
//JJ     f.write(_zxCpu.registers.byte[Z80_D]);
//JJ     f.write(_zxCpu.registers.byte[Z80_C]);
//JJ     f.write(_zxCpu.registers.byte[Z80_B]);
//JJ     f.write(_zxCpu.registers.byte[Z80_F]);
//JJ     f.write(_zxCpu.registers.byte[Z80_A]);
//JJ 
//JJ     // restore registers
//JJ     _zxCpu.registers.word[Z80_HL] = HL;
//JJ     _zxCpu.registers.word[Z80_DE] = DE;
//JJ     _zxCpu.registers.word[Z80_BC] = BC;
//JJ     _zxCpu.registers.word[Z80_AF] = AF;
//JJ 
//JJ     // write registers
//JJ     f.write(_zxCpu.registers.byte[Z80_L]);
//JJ     f.write(_zxCpu.registers.byte[Z80_H]);
//JJ     f.write(_zxCpu.registers.byte[Z80_E]);
//JJ     f.write(_zxCpu.registers.byte[Z80_D]);
//JJ     f.write(_zxCpu.registers.byte[Z80_C]);
//JJ     f.write(_zxCpu.registers.byte[Z80_B]);
//JJ     f.write(_zxCpu.registers.byte[Z80_IYL]);
//JJ     f.write(_zxCpu.registers.byte[Z80_IYH]);
//JJ     f.write(_zxCpu.registers.byte[Z80_IXL]);
//JJ     f.write(_zxCpu.registers.byte[Z80_IXH]);
//JJ 
//JJ     byte inter = _zxCpu.iff2 ? 0x04 : 0;
//JJ     f.write(inter);
//JJ     f.write(_zxCpu.r);
//JJ 
//JJ     f.write(_zxCpu.registers.byte[Z80_F]);
//JJ     f.write(_zxCpu.registers.byte[Z80_A]);
//JJ 
//JJ     // read stack pointer and decrement it for pushing PC
//JJ     unsigned short SP = _zxCpu.registers.word[Z80_SP];
//JJ     SP -= 2;
//JJ     byte sp_l = SP & 0xFF;
//JJ     byte sp_h = SP >> 8;
//JJ     f.write(sp_l);
//JJ     f.write(sp_h);
//JJ 
//JJ     f.write(_zxCpu.im);
//JJ     byte bordercol = borderTemp;
//JJ     f.write(bordercol);
//JJ 
//JJ     // push PC to stack
//JJ     unsigned short PC = _zxCpu.pc;
//JJ     byte pc_l = PC & 0xFF;
//JJ     byte pc_h = PC >> 8;
//JJ     writebyte(SP+0, pc_l);
//JJ     writebyte(SP+1, pc_h);
//JJ 
//JJ     // dump memory to file
//JJ     for (int addr = 0x4000; addr <= 0xFFFF; addr++) {
//JJ         byte b = readbyte(addr);
//JJ         f.write(b);
//JJ     }
//JJ 
//JJ     f.close();
//JJ     return true;
//JJ     KB_INT_START;
//JJ }




//JJ static byte* snabuf = NULL;

//JJ bool is_quick_sna_available()
//JJ {
//JJ     return snabuf != NULL;
//JJ }

//JJ bool save_ram_quick()
//JJ {
//JJ     KB_INT_STOP;
//JJ 
//JJ     // only 48K snapshot supported at the moment
//JJ     if (cfg_arch != "48K") {
//JJ         Serial.println("save_ram_quick: only 48K supported at the moment");
//JJ         KB_INT_START;
//JJ         return false;
//JJ     }
//JJ 
//JJ     // allocate buffer it not done yet
//JJ     if (snabuf == NULL)
//JJ     {
//JJ #define JJ_BOARD_HAS_PSRAM        
//JJ #ifdef JJ_BOARD_HAS_PSRAM
//JJ         //JJsnabuf = (byte*)ps_malloc(49179);
//JJ         snabuf = NULL;
//JJ         return false;
//JJ #else
//JJ         //JJ snabuf = (byte*)malloc(49179);
//JJ         snabuf = NULL;
//JJ         return false;
//JJ #endif
//JJ         if (snabuf == NULL) {
//JJ             Serial.println("save_ram_quick: cannot allocate memory for snapshot buffer");
//JJ             KB_INT_START;
//JJ             return false;
//JJ         }
//JJ     }
//JJ 
//JJ     byte* snaptr = snabuf;
//JJ 
//JJ     // write registers: begin with I
//JJ     *snaptr++ = _zxCpu.i;
//JJ 
//JJ     // store registers
//JJ     unsigned short HL = _zxCpu.registers.word[Z80_HL];
//JJ     unsigned short DE = _zxCpu.registers.word[Z80_DE];
//JJ     unsigned short BC = _zxCpu.registers.word[Z80_BC];
//JJ     unsigned short AF = _zxCpu.registers.word[Z80_AF];
//JJ 
//JJ     // put alternates in registers
//JJ     _zxCpu.registers.word[Z80_HL] = _zxCpu.alternates[Z80_HL];
//JJ     _zxCpu.registers.word[Z80_DE] = _zxCpu.alternates[Z80_DE];
//JJ     _zxCpu.registers.word[Z80_BC] = _zxCpu.alternates[Z80_BC];
//JJ     _zxCpu.registers.word[Z80_AF] = _zxCpu.alternates[Z80_AF];
//JJ 
//JJ     // write alternates
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_L];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_H];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_E];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_D];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_C];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_B];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_F];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_A];
//JJ 
//JJ     // restore registers
//JJ     _zxCpu.registers.word[Z80_HL] = HL;
//JJ     _zxCpu.registers.word[Z80_DE] = DE;
//JJ     _zxCpu.registers.word[Z80_BC] = BC;
//JJ     _zxCpu.registers.word[Z80_AF] = AF;
//JJ 
//JJ     // write registers
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_L];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_H];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_E];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_D];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_C];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_B];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_IYL];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_IYH];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_IXL];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_IXH];
//JJ 
//JJ     byte inter = _zxCpu.iff2 ? 0x04 : 0;
//JJ     *snaptr++ = inter;
//JJ     *snaptr++ = _zxCpu.r;
//JJ 
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_F];
//JJ     *snaptr++ = _zxCpu.registers.byte[Z80_A];
//JJ 
//JJ     // read stack pointer and decrement it for pushing PC
//JJ     unsigned short SP = _zxCpu.registers.word[Z80_SP];
//JJ     SP -= 2;
//JJ     byte sp_l = SP & 0xFF;
//JJ     byte sp_h = SP >> 8;
//JJ     *snaptr++ = sp_l;
//JJ     *snaptr++ = sp_h;
//JJ 
//JJ     *snaptr++ = _zxCpu.im;
//JJ     byte bordercol = borderTemp;
//JJ     *snaptr++ = bordercol;
//JJ 
//JJ     // push PC to stack
//JJ     unsigned short PC = _zxCpu.pc;
//JJ     byte pc_l = PC & 0xFF;
//JJ     byte pc_h = PC >> 8;
//JJ     writebyte(SP+0, pc_l);
//JJ     writebyte(SP+1, pc_h);
//JJ 
//JJ     // dump memory to file
//JJ     for (int addr = 0x4000; addr <= 0xFFFF; addr++) {
//JJ         byte b = readbyte(addr);
//JJ         *snaptr++ = b;
//JJ     }
//JJ 
//JJ     KB_INT_START;
//JJ     return true;
//JJ }


//JJ bool load_ram_quick()
//JJ {
//JJ     // only 48K snapshot supported at the moment
//JJ     if (cfg_arch != "48K") {
//JJ         Serial.println("save_ram_quick: only 48K supported at the moment");
//JJ         KB_INT_START;
//JJ         return false;
//JJ     }
//JJ 
//JJ     if (NULL == snabuf) {
//JJ         // nothing to read
//JJ         Serial.println("save_ram_quick: nothing to load");
//JJ         KB_INT_START;
//JJ         return false;
//JJ     }
//JJ 
//JJ     byte* snaptr = snabuf;
//JJ 
//JJ     // Read in the registers
//JJ     _zxCpu.i = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_L] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_H] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_E] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_D] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_C] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_B] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_F] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_A] = *snaptr++;
//JJ 
//JJ     _zxCpu.alternates[Z80_HL] = _zxCpu.registers.word[Z80_HL];
//JJ     _zxCpu.alternates[Z80_DE] = _zxCpu.registers.word[Z80_DE];
//JJ     _zxCpu.alternates[Z80_BC] = _zxCpu.registers.word[Z80_BC];
//JJ     _zxCpu.alternates[Z80_AF] = _zxCpu.registers.word[Z80_AF];
//JJ 
//JJ     _zxCpu.registers.byte[Z80_L] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_H] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_E] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_D] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_C] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_B] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_IYL] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_IYH] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_IXL] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_IXH] = *snaptr++;
//JJ 
//JJ     byte inter = *snaptr++;
//JJ     _zxCpu.iff2 = (inter & 0x04) ? 1 : 0;
//JJ     _zxCpu.r = *snaptr++;
//JJ 
//JJ     _zxCpu.registers.byte[Z80_F] = *snaptr++;
//JJ     _zxCpu.registers.byte[Z80_A] = *snaptr++;
//JJ 
//JJ     byte sp_l = *snaptr++;
//JJ     byte sp_h = *snaptr++;
//JJ     _zxCpu.registers.word[Z80_SP] = sp_l + sp_h * 0x100;
//JJ 
//JJ     _zxCpu.im = *snaptr++;
//JJ     byte bordercol = *snaptr++;
//JJ 
//JJ     borderTemp = bordercol;
//JJ 
//JJ     _zxCpu.iff1 = _zxCpu.iff2;
//JJ 
//JJ     uint16_t thestack = _zxCpu.registers.word[Z80_SP];
//JJ     for (int addr = 0x4000; addr <= 0xFFFF; addr++) {
//JJ         writebyte(addr, *snaptr++);
//JJ     }
//JJ 
//JJ     uint16_t retaddr = readword(thestack);
//JJ     Serial.printf("%x\n", retaddr);
//JJ     _zxCpu.registers.word[Z80_SP]++;
//JJ     _zxCpu.registers.word[Z80_SP]++;
//JJ 
//JJ     _zxCpu.pc = retaddr;
//JJ 
//JJ     KB_INT_START;
//JJ     return true;
//JJ }