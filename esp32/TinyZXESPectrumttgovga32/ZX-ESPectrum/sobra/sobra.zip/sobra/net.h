/*
// Netword methods
void wifiConn();
*/
