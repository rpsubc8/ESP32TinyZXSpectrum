//JJ #include <FS.h>
//JJ extern boolean cfg_demo_mode_on;
//JJ extern unsigned short cfg_demo_every;
//JJ extern String cfg_sna_file_list;
//extern String cfg_arch;
//JJ extern String cfg_ram_file;
//JJ extern String cfg_rom_set;
//extern String cfg_sna_name_list;
//extern boolean cfg_slog_on;
//JJ extern boolean cfg_wconn;
//JJ extern String cfg_wssid;
//JJ extern String cfg_wpass;

//JJ void IRAM_ATTR mount_spiffs();
//JJ String getAllFilesFrom(const String path);
//JJ void listAllFiles();
//JJ File IRAM_ATTR open_read_file(String filename);
//JJ void IRAM_ATTR load_ram(String sna_file);
//JJ bool IRAM_ATTR save_ram(String sna_file);
//JJ bool IRAM_ATTR load_ram_quick();
//JJ bool IRAM_ATTR save_ram_quick();
//JJ bool IRAM_ATTR is_quick_sna_available();
//JJ bool IRAM_ATTR is_persist_sna_available();
//JJ String getFileEntriesFromDir(String path);
//JJ unsigned short countFileEntriesFromDir(String path);
//JJ rom void load_rom(String arch, String romset);
//JJ String getSnaFileList();
//JJ SPIFFS void config_read();
//JJ void IRAM_ATTR config_save();//No la necesitamos por ahora